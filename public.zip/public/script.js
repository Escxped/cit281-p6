const itemForm = document.getElementById('itemForm');
const itemInput = document.getElementById('itemInput');
const itemList = document.getElementById('itemList');

// Load items on page load
window.onload = loadItems;

// Handle form submit
itemForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = itemInput.value.trim();
  if (!name) return;

  const res = await fetch('/api/items', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name })
  });

  const newItem = await res.json();
  addItemToDOM(newItem);
  itemInput.value = '';
});

// Load and display items
async function loadItems() {
  const res = await fetch('/api/items');
  const items = await res.json();
  itemList.innerHTML = '';
  items.forEach(addItemToDOM);
}

// Add item to the DOM
function addItemToDOM(item) {
  const li = document.createElement('li');
  li.textContent = `${item.name} (ID: ${item.id})`;
  itemList.appendChild(li);
}
